#include <iostream>

int main()
{
    
}