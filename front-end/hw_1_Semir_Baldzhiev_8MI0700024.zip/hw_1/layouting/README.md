# Task 2: Layouting

Имплементирайте файловете от папка `pages` спрямо посочените резултати.

![image](https://user-images.githubusercontent.com/5821279/201119416-7b2f3a67-7cf5-4230-9c0d-6cd1bbeedcb5.png)
![image](https://user-images.githubusercontent.com/5821279/201119853-0e584068-9122-44f1-b571-479c51a367c9.png)
![image](https://user-images.githubusercontent.com/5821279/201119509-afa613c5-4210-4f00-9e84-2468094d2b7d.png)
![image](https://user-images.githubusercontent.com/5821279/201119549-ee64926a-3c58-44c9-b527-919247b9a6a0.png)
